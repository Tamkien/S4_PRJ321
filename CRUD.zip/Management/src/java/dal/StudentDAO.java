/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Student;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Department;

/**
 *
 * @author trant
 */
public class StudentDAO extends BaseDAO {

    public ArrayList<Student> getStudents() {
        ArrayList<Student> students = new ArrayList<>();
        try {
            String sql = "SELECT s.sid,s.name,s.gender,s.dob,d.did,d.dname FROM Student1 s INNER JOIN Department1 d\n"
                    + "ON s.did = d.did";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                Department d = new Department();
                d.setId(rs.getInt("did"));
                d.setName(rs.getString("dname"));
                Student s = new Student();
                s.setId(rs.getInt("sid"));
                s.setName(rs.getString("name"));
                s.setDob(rs.getDate("dob"));
                s.setGender(rs.getBoolean("gender"));
                s.setDepartment(d);
                students.add(s);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DepartmentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return students;
    }

    public Student getStudent(int id) {
        try {
            String sql = "SELECT s.sid,s.name,s.gender,s.dob,d.did,d.dname FROM Student1 s INNER JOIN Department1 d\n"
                    + "ON s.did = d.did WHERE s.sid = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                Department currentDept = new Department();
                currentDept.setId(rs.getInt("did"));
                currentDept.setName(rs.getString("dname"));
                Student s = new Student();
                s.setId(rs.getInt("sid"));
                s.setName(rs.getString("name"));
                s.setDob(rs.getDate("dob"));
                s.setGender(rs.getBoolean("gender"));
                s.setDepartment(currentDept);
                return s;
            }

        } catch (SQLException ex) {
            Logger.getLogger(DepartmentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void insertStudent(Student s) {
        try {
            String sql = "INSERT INTO [Student1]\n"
                    + "           ([sid]\n"
                    + "           ,[name]\n"
                    + "           ,[dob]\n"
                    + "           ,[gender]\n"
                    + "           ,[did])\n"
                    + "     VALUES\n"
                    + "           (?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?\n"
                    + "           ,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, s.getId());
            statement.setString(2, s.getName());
            statement.setDate(3, (java.sql.Date) s.getDob());
            statement.setBoolean(4, s.isGender());
            statement.setInt(5, s.getDepartment().getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateStudent(Student s) {
        try {
            String sql = "UPDATE [Student1]\n"
                    + "   SET [name] = ?\n"
                    + "      ,[dob] = ?\n"
                    + "      ,[gender] = ?\n"
                    + "      ,[did] = ?\n"
                    + " WHERE [sid] = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, s.getName());
            statement.setDate(2, (java.sql.Date) s.getDob());
            statement.setBoolean(3, s.isGender());
            statement.setInt(4, s.getDepartment().getId());
            statement.setInt(5, s.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void deleteStudent(int id) {
        try {
            String sql = "DELETE Student1 WHERE sid=?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(StudentDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
