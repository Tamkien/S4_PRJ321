/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.*;

/**
 *
 * @author trant
 */
public class CandidateDAO extends BaseDAO {

    public ArrayList<Candidate> getCandidates() {
        ArrayList<Candidate> candidates = new ArrayList<>();
        try {
            String sql = "select * from Candidate3";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Candidate candidate = new Candidate();
                candidate.setId(rs.getString("id"));
                candidate.setName(rs.getString("name"));
                candidate.setMale(rs.getBoolean("gender"));
                candidate.setDob(rs.getDate("dob"));
                candidates.add(candidate);
            }
        } catch (SQLException e) {
            Logger.getLogger(CandidateDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return candidates;
    }

    public ArrayList<Candidate> searchCandidates(candidateQuerry c) {
        ArrayList<Candidate> candidates = new ArrayList<>();
        try {
            String sql = "SELECT [id]\n"
                    + "      ,[name]\n"
                    + "      ,[gender]\n"
                    + "      ,[dob]\n"
                    + "  FROM Candidate3\n"
                    + "  where id like ? + '%' and\n"
                    + "  name like ? + '%' and\n"
                    + "  dob between ? and ? \n";
            if (c.getGender() != 2) {
                sql += " and gender = ?";
            }
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, c.getId().isEmpty() ? "" : c.getId());
            statement.setString(2, c.getName().isEmpty() ? "" : c.getName());
            statement.setDate(3, (java.sql.Date) c.getFrom());
            statement.setDate(4, (java.sql.Date) c.getTo());
            if (c.getGender() != 2) {
                statement.setInt(5, c.getGender());
            }
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Candidate candidate = new Candidate();
                candidate.setId(rs.getString("id"));
                candidate.setName(rs.getString("name"));
                candidate.setMale(rs.getBoolean("gender"));
                candidate.setDob(rs.getDate("dob"));
                candidates.add(candidate);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CandidateDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return candidates;
    }
}
