/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author trant
 */
public class candidateQuerry {
    String id;
    String name;
    int gender;
    Date from, to;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public Date getFrom() {
        return from;
    }

    public void setFrom(Date from) {
        this.from = from;
    }

    public Date getTo() {
        return to;
    }

    public void setTo(Date to) {
        this.to = to;
    }

    public candidateQuerry() {
    }

    public candidateQuerry(String id, String name, int gender, Date from, Date to) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.from = from;
        this.to = to;
    }

}